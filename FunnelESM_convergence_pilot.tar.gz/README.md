# Funnel-ESM

Primer baseline de clasificación multilabel de DeepLoc 2.0 con ESM-2 y las
APIs de Hugging Face.

Incluye también variantes inspiradas en FunnelTransformer que reducen la
longitud de la secuencia entre bloques de capas de ESM-2.

## Archivos

```text
scripts/train_baseline.py
scripts/train_funnel.py
scripts/train_funnel_pool_query.py
src/funnel_esm/data.py
src/funnel_esm/metrics.py
src/funnel_esm/pooling.py
src/funnel_esm/modeling_funnel_esm.py
```

- `data.py` carga el CSV mediante `datasets.load_dataset`, separa una de las
  cinco particiones para validación y tokeniza las secuencias.
- `metrics.py` calcula macro-F1, micro-F1, Jaccard, accuracy exacta y el
  número medio de etiquetas predichas.
- `train_baseline.py` ejecuta la validación cruzada de cinco folds y mide
  energía, tiempo y memoria GPU.
- `pooling.py` implementa una media enmascarada de residuos consecutivos,
  preservando `<cls>`, `<eos>` y las posiciones originales para RoPE.
- `modeling_funnel_esm.py` reutiliza las capas de la implementación ESM de
  Transformers e introduce una o varias reducciones entre ellas.
- `train_funnel.py` usa el mismo entrenamiento y evaluación del baseline con
  el encoder reducido.
- `train_funnel_pool_query.py` conserva K/V sin comprimir en la primera capa
  posterior al pooling y comprime solamente Q con stride 2.

## Instalación

```bash
pip install -e .
```

## Comprobación de Zeus

```bash
python -m zeus.show_env
```

## Entrenamiento en una GPU

```bash
python scripts/train_baseline.py \
    --dataset_path /ruta/multisub_5_partitions_unique.csv \
    --output_dir outputs/baseline
```

## Entrenamiento distribuido

Por ejemplo, con dos GPU:

```bash
torchrun --standalone --nproc_per_node=2 scripts/train_baseline.py \
    --dataset_path /ruta/multisub_5_partitions_unique.csv \
    --output_dir outputs/baseline
```

## Primera reducción interna

El siguiente comando aplica pooling después de la capa 6 del modelo ESM-2 de
12 capas. `pool_after_layers` cuenta las capas desde 1:

```bash
torchrun --standalone --nproc_per_node=2 scripts/train_funnel.py \
    --dataset_path /ruta/multisub_5_partitions_unique.csv \
    --output_dir outputs/funnel_mean_layer_6 \
    --batch_size 4 \
    --epochs 2 \
    --pool_after_layers 6
```

Con dos GPU y `--batch_size 4`, el batch global es 8, igual que en el
baseline. La reducción transforma los residuos de `[B, L, D]` a
aproximadamente `[B, L/2, D]`; no reduce la dimensión oculta `D`.

Los tokens `<cls>` y `<eos>` se conservan. Para RoPE, un token que agrupa las
posiciones originales 5 y 6 recibe la posición 5.5, en lugar de renumerarse
como si las distancias originales se hubieran reducido.

## Pool-query-only

Esta variante mantiene exactamente el mismo mean pooling con stride 2, pero
en la primera capa posterior a la reducción usa Q comprimida y K/V a longitud
original:

```bash
torchrun --standalone --nproc_per_node=2 \
    scripts/train_funnel_pool_query.py \
    --dataset_path /ruta/multisub_5_partitions_unique.csv \
    --output_dir outputs/funnel_pool_query_layer_6 \
    --batch_size 4 \
    --epochs 2 \
    --pool_after_layers 6
```

En la transición entre las capas 6 y 7, la capa 7 calcula una atención de
tamaño aproximado `[L/2, L]`. Su salida ya tiene longitud `L/2`, por lo que
las capas 8 a 12 funcionan normalmente con Q, K y V comprimidas.

RoPE se aplica por separado: Q usa las posiciones medias producidas por el
pooling y K conserva las posiciones originales. La variante no introduce
parámetros entrenables nuevos.

## Varias reducciones

`--pool_after_layers` acepta una lista ordenada de capas. Cada número indica
una transición con stride 2:

```bash
# Una reducción: longitud aproximada L/2
--pool_after_layers 6

# Dos reducciones: longitud aproximada L/4
--pool_after_layers 4 8

# Tres reducciones: longitud aproximada L/8
--pool_after_layers 3 6 9
```

Por ejemplo, la configuración `4 8` forma tres bloques de cuatro capas. En
mean pooling se reduce después de las capas 4 y 8. En pool-query-only, las
capas 5 y 9 usan Q comprimida y K/V a la resolución del bloque anterior.
Las demás capas utilizan Q, K y V con la misma longitud.

El argumento anterior `--pool_after_layer 6` sigue disponible para ejecutar
una sola reducción, pero no se puede combinar con `--pool_after_layers`.

## Piloto de convergencia

Antes de repetir la validación cruzada completa, el piloto compara en un solo
fold cinco configuraciones:

- baseline;
- mean pooling después de la capa 6;
- mean pooling después de las capas 4 y 8;
- pool-query-only después de la capa 6;
- pool-query-only después de las capas 4 y 8.

Cada configuración se entrena con `LR/3`, `LR` y `3*LR`. Por ejemplo:

```bash
nohup python scripts/run_convergence_pilot.py \
    --dataset_path data/Swissprot_Train_Validation_dataset.csv \
    --output_dir outputs/convergence_pilot \
    --fold 0 \
    --batch_size 8 \
    --epochs 10 \
    --base_learning_rate 5e-4 \
    --nproc_per_node 1 \
    > convergence_pilot.log 2>&1 &
```

El lanzador usa `torchrun` internamente y ejecuta los 15 entrenamientos de
forma secuencial. Se puede comprobar primero la matriz sin entrenar:

```bash
python scripts/run_convergence_pilot.py \
    --dataset_path data/Swissprot_Train_Validation_dataset.csv \
    --dry_run
```

Cada ejecución guarda `fold_0/epoch_history.json`. Cuando termina el piloto se
crean también:

- `pilot_manifest.json`, con todos los comandos y configuraciones;
- `learning_curves.csv`, con una fila por época y ejecución;
- `pilot_summary.json`, con la mejor época según macro-F1.

Si el piloto se interrumpe, se puede continuar omitiendo las ejecuciones que
ya hayan terminado:

```bash
python scripts/run_convergence_pilot.py \
    --dataset_path data/Swissprot_Train_Validation_dataset.csv \
    --skip_existing
```

También se puede ejecutar manualmente un único entrenamiento piloto añadiendo
`--folds 0 --eval_each_epoch` a cualquiera de los tres scripts de
entrenamiento.

El script entrena cinco modelos independientes. Cada partición se utiliza una
vez como conjunto de evaluación y las otras cuatro como entrenamiento. Al
terminar escribe `cross_validation_results.json`, con los resultados de cada
fold y la media y desviación típica de todas las métricas.

La energía GPU y el tiempo corresponden únicamente a `Trainer.train()`. La
memoria es el máximo de memoria CUDA asignada durante el entrenamiento. Con
`torchrun`, se suma la energía de todas las GPU y se toma el máximo del tiempo
y de la memoria por GPU.

El identificador `facebook/esm2_t12_35M_UR50D` hace referencia al checkpoint
publicado por Meta en Hugging Face Hub. El modelo se carga con
`AutoModelForSequenceClassification`, es decir, con la implementación de
Transformers.

Por defecto:

- se ejecutan los cinco folds;
- se excluyen secuencias de más de 1024 residuos;
- se congela el encoder ESM-2;
- se entrena solamente la cabeza de clasificación;
- se usa el token `<cls>` como representación de la proteína;
- se usa un umbral de 0.5 para convertir probabilidades en etiquetas.
